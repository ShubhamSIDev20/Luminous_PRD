﻿using Blazicons;

namespace BatteryTestingSystem.Components.UI.WindowManager;

public class WindowModel
{
    public string Id { get; set; } = Guid.NewGuid().ToString();
    public string Title { get; set; }
    public SvgIcon Icon { get; set; }
    public WindowState State { get; set; } = WindowState.Normal;
    public WindowPosition Position { get; set; } = new();
    public WindowSize Size { get; set; } = new() { Width = 800, Height = 600 };
    public bool IsDocked { get; set; }
    public DockPosition DockPosition { get; set; }
    public int ZIndex { get; set; }
}

public class WindowPosition
{
    public double X { get; set; } = 100;
    public double Y { get; set; } = 100;
}

public class WindowSize
{
    public double Width { get; set; }
    public double Height { get; set; }
    public double? MinWidth { get; set; } = 300;
    public double? MinHeight { get; set; } = 200;
}

public enum WindowState { Normal, Minimized, Maximized }
public enum DockPosition { None, Left, Right, Top, Bottom }
